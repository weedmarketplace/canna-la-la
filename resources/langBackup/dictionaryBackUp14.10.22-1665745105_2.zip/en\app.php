<?php
 return[
	"email" => "email",
	"notifiction" => "notif",
	"request_quote" => "Request quote",
];