<?php

return [
    'new_order_title' => 'New order',
    'new_order_text' => 'You have new order in category :category',
    'order_canceled_title' => 'Order canceled',
    'order_canceled_text' => 'Your order in category :category is canceled',
    'order_approved_title' => 'Order approved',
    'order_approved_text' => 'Your order is approved',
    'order_declined_title' => 'Order declined',
    'order_declined_text' => 'Your order is declined',
    'order_timeout_title' => 'Timeout order',
    'order_timeout_text_customer' => 'Your order canceled by timeout',
    'order_timeout_text_employee' => 'You order canceled becouse of no respose',
];
