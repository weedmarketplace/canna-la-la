<?php
 return[
	"order_canceled_subject" => "Order :sku canceled.",
	"order_canceled_text" => "Order :sku canceled.",
	"order_canceled_title" => "Order canceled",
	"order_done_subject" => "Order :sku done.",
	"order_done_text" => "Order :sku successfully done.",
	"order_done_title" => "Order done",
	"order_paid_subject" => "Order :sku paid.",
	"order_paid_text" => "Order :sku successfully paid.",
	"order_paid_title" => "Payment success",
	"order_shipping_subject" => "Order :sku shipping.",
	"order_shipping_text" => "Order :sku shipping.",
	"order_shipping_title" => "Order shipping",
	"email.footer" =>  "Copyright © 2022 WTD. All rights reserved.",
	"email.header" =>  "WTD LLC",
];