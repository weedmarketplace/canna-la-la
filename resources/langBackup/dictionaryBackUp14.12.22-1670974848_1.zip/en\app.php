<?php
 return[
	"contact_email" => "info@witdthedoc.com",
	"copyright" => "Copyright © 2022 WTD. All rights reserved.",
	"facebook_url" => "https://facebook.com",
	"homepage_icon1_text" => "I did not even know that there werdsfdsfdse any better conditions to escape to, but I was more than wd my chancesfsdfs among people fashioned after.",
	"homepage_icon1_title" => "Fast shipping",
	"homepage_icon2_text" => "I did not even know that there were any better conditions to escape to, but I was more than willing to take my chances among people fashioned after.",
	"homepage_icon2_title" => "14 days return",
	"homepage_icon3_text" => "I did not even know that there were any better conditions to escape to, but I was more than willing to take my chances among people fashioned after.",
	"homepage_icon3_title" => "Perfect quality",
	"homepage_more_products" => "discover more",
	"homepage_products_description" => "I did not even know that there were any better conditions to escape to, but I was more than willing 
	to take my chances among people fashioned after.",
	"homepage_products_title" => "Featured product",
	"homepage_video_title" => "skin tones<br>exclisive collection",
	"homepage_video_url" => "https://www.youtube.com/watch?v=_sI_Ps7JSEk",
	"instagram_url" => "https://instagram.com",
];