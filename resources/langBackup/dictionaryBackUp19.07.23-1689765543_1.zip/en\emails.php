<?php
 return[
	"email.footer" => "Copyright © 2022 The House. All rights reserved.",
	"email.header" => "The House LLC",
	"password_recovery_title" => "Password Recovery Request",
	"password_recovery_reset_password" => "Reset password",
	"password_recovery_description" => "It seems like you have requested a password reset for your account. Please click on the link below to create a new password.",
	"order_created_text" => "Order :sku successfully created.",
	"order_created_title" => "Order created",
	"view_order" => "View order",
	"order_created_subject" => "Order :sku created",
];