<?php
 return[
  "header_sign_in" => "Մուտք",
  "blog_blog" => "Բլոգ",
  "blog_read_more" => "կարդալ ավելին",
  "blog_see_more" => "տեսնել ավելին",
  "product_you_like" => "Դուք կհավանեք նաև",
  "product_detailed_description" => "Մանրամասն նկարագրություն",
  "product.combination_with_food" => "Սննդի հետ համադրություն",
  "recipe.address" => "Հասցեներ",
  "phone_number" => "Հեռախոսահամար",
  "working_schedule" => "Աշխատանքային գրաֆիկ",
  "address_Feedback" => "Հետադարձ կապ",
  "address_question" => "Դեռ ունե՞ք հարցեր, հաստատեք կապ մեզ հետ",
  "address_name_surname" => "Անուն Ազգանուն",
  "address_email" => "Էլեկտրոնային հասցե",
  "address_message" => "Հաղորդագրություն",
  "address_send" => "Ուղարկել",
  "blogPage.similar_articles" => "Նմանատիպ հոդվածներ",
  "asked_questions" => "Հաճախ տրվող հարցեր",
];

