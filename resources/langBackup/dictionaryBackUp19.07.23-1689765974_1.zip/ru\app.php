<?php
 return[
  "header_sign_in" => "Вход",
  "blog_blog" => "блог",
  "blog_read_more" => "читать далее",
  "blog_see_more" => "узнать больше",
  "product_you_like" => "Вам это тоже понравится",
  "product_detailed_description" => "Подробное описание",
  "product.combination_with_food" => "Сочетание с едой",
  "recipe.address" => "Адреса",
  "recipe_how_to_get" => "Как туда добраться?",
  "phone_number" => "Номер телефона",
  "working_schedule" => "Рабочее расписание",
  "address_Feedback" => "Обратная связь",
  "address_question" => "Остались вопросы, свяжитесь с нами",
  "address_name_surname" => "Имя Фамилия",
  "address_email" => "Электронная почта",
  "address_message" => "Сообщение",
  "address_send" => "Отправлять",
  "blogPage.similar_articles" => "Похожие статьи",
  "asked_questions" => "Часто задаваемые вопросы",

 ];
