<?php
 return[
	"email.footer" => "Աշխատանքային գրաֆիկ",
	"email.header" => "Աշխատանքային գրաֆիկ",
	"order_created_subject" => "Աշխատանքային գրաֆիկ",
	"order_created_text" => "Աշխատանքային գրաֆիկ",
	"order_created_title" => "Աշխատանքային գրաֆիկ",
	"password_recovery_description" => "Աշխատանքային գրաֆիկ",
	"password_recovery_reset_password" => "Աշխատանքային գրաֆիկ",
	"password_recovery_title" => "Աշխատանքային գրաֆիկ",
	"view_order" => "Աշխատանքային գրաֆիկ",
];