<?php
 return[
	"email.footer" => "Рабочее расписание",
	"email.header" => "Рабочее расписание",
	"order_created_subject" => "Рабочее расписание",
	"order_created_text" => "Рабочее расписание",
	"order_created_title" => "Рабочее расписание",
	"password_recovery_description" => "Рабочее расписание",
	"password_recovery_reset_password" => "Рабочее расписание",
	"password_recovery_title" => "Рабочее расписание",
	"view_order" => "Рабочее расписание",
];