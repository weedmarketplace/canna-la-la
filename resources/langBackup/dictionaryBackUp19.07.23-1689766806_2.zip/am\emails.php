<?php
 return[
	"email.footer" => "",
	"email.header" => "",
	"order_created_subject" => "",
	"order_created_text" => "",
	"order_created_title" => "",
	"password_recovery_description" => "",
	"password_recovery_reset_password" => "",
	"password_recovery_title" => "",
	"view_order" => "",
];