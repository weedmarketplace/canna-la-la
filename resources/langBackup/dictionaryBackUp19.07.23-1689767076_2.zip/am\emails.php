<?php
 return[
	"email.footer" => "Copyright © 2022 The House. All rights reserved.",
	"email.header" => "The House LLC",
	"order_created_subject" => "Պատվիրը :sku ստեղծվել է",
	"order_created_text" => "Պատվերը :sku հաջողությամբ գրանցվել է",
	"order_created_title" => "Պատվիրը ստեղծվել է",
	"password_recovery_description" => "Խնդրում ենք սեղմել ստորև նշված հղման վրա՝ նոր գաղտնաբառ ստեղծելու համար:",
	"password_recovery_reset_password" => "Վերականգնել գաղտնաբառը",
	"password_recovery_title" => "Գաղտնաբառի վերականգնման հարցում",
	"view_order" => "Դիտել պատվերը1",
];