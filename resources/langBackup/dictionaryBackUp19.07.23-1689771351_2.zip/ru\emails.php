<?php
 return[
	"email.footer" => "Copyright © 2022 The House. All rights reserved.",
	"email.header" => "The House LLC",
	"order_created_subject" => "Заказ :sku создан",
	"order_created_text" => "Заказ :sku успешно создан",
	"order_created_title" => "Заказ создан",
	"password_recovery_description" => "Похоже, вы запросили сброс пароля для своей учетной записи. Нажмите на ссылку ниже, чтобы создать новый пароль",
	"password_recovery_reset_password" => "Сброс пароля",
	"password_recovery_title" => "Запрос на восстановление пароля",
	"view_order" => "Посмотреть заказ",
];