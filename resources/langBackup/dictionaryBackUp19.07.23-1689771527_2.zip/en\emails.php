<?php
 return[
	"email.footer" => "Copyright © 2022 The House. All rights reserved.",
	"email.header" => "The House LLC",
	"order_created_subject" => "Order :sku created",
	"order_created_text" => "Order :sku successfully created.",
	"order_created_title" => "Order created",
	"password_recovery_description" => "It seems like you have requested a password reset for your account. Please click on the link below to create a new password.",
	"password_recovery_reset_password" => "Reset password",
	"password_recovery_title" => "Password Recovery Request",
	"view_order" => "View order",
];