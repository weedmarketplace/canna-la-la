<?php
 return[
	"header_sign_in" => "Вход",
];