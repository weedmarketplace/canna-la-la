<?php
 return[
	"header_sign_in" => "Sign",
];